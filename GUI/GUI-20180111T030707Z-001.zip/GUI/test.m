x1=imread('1.jpg');
x=rgb2gray(x1);
w=cplx(x,1,Faf,af);